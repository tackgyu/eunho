/**
 * keti,
 * the Map of javascript 
 */

function JsMap(){
	
	this._array = new Array(); // array of map
	this. js_map_pointer = 0;
	this._get_indexByKey = function(key){
		for(var i = 0; i < this._array.length; i++){
			if(key == this._array[i][0]){
				return i;
			}
		}
		return -1;
	}
	
	this.put = function(key, value){
		var _index = this._get_indexByKey(key);
		if(_index == -1){
			var newArray = new Array(); // array of load key, value
			newArray[0] = key;
			newArray[1] = value;
			this._array[this._array.length] = newArray;
		} else {
			this._array[_index][1] = value;
		}
	}
	
	this.get = function(key){
		for(var i = 0; i < this._array.length; i++){
			if(this._array[i][0]==key)
				return this._array[i][1];
		}
	}
	
	this.isNext = function(){
		var js_map_result;
		if(this._array.length > this. js_map_pointer){
			js_map_result = true;
		} else {
			js_map_result = false;
		}
		this.js_map_pointer++;
		return js_map_result;
	}
	
	this.isContain = function(key){
		var js_map_result = false;
		for(var i = 0; i < this._array.length; i++){
			if(this._array[i][0] == key)
				js_map_result = true;
		}
		return js_map_result;
	}
	
	this.size = function(){
		return this._array.length;
	}
	this.nowKey = function(){
		return this._array[this.js_map_pointer-1][0];
	}
	
	this.nowValue = function(){
		return this._array[this.js_map_pointer-1][1];
	}
	
	this.MaxValue = function(){
		var js_map_result = -1;
		for(var i = 0; i < this._array.length; i++){
			js_map_result = (js_map_result < this._array[i][1]) ?
				this._array[i][1] : js_map_result;
		}
		return js_map_result;
	}
	
}
