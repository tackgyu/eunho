$(document).ready(function() {
	eventHandler_provider();
	init_ui();
});

function eventHandler_provider(){
	$("#getContext_USER").click(function() {
		getContext_USER();
	});
	$("#getContext_PAGE").click(function() {
		getContext_PAGE();
	});
	$("#getContext").click(function() {
		getContext();
	});
};

function init_ui(){
	$.ajax({
		type : "get",
		url : "../context/getContextAll",
		dataType : "json",
		success : function(data) {
			console.log(data);
			for(var i = 0 ; i < data.length; i++){
				var append_option='<option value='; 
				    append_option += data[i].userID + '>' + data[i].userID + '</option>';
				    $("#UserId_welcome").append(append_option);
			}
		},
		error : function(e) {
			alert('너 실패');
		}
	});
	$.ajax({
		type : "get",
		url : "../context/getPageAll",
		dataType : "json",
		success : function(data) {
			console.log(data);
			for(var i = 0 ; i < data.length; i++){
				var append_option='<option value='; 
				    append_option += data[i].id + '>' + data[i].title + '</option>';
				    $("#PageId_welcome").append(append_option);
			}
		},
		error : function(e) {
			alert('너 실패');
		}
	});
};


function ctxSerOrUp(){
	var p_id_wel = $("#PageId_welcome").val();
	var u_id_wel = $("#UserId_welcome").val();
	var cur_ctx = [];
	var to_transfer='{"ContextUserID":"'+u_id_wel+'",'; 
	
		var childs_to = $("#ctx_container").children();
		 for(var i = 0; i < childs_to.length-1; i++){
			 if( $("#"+childs_to[i].id).children().children().last().val()){
				 to_transfer += '"' + $("#"+childs_to[i].id).children().children().first().text() + 
				                '":"' + $("#"+childs_to[i].id).children().children().last().val() +'"';
			 } else {
				 console.log( $("#"+childs_to[i].id).children().children().first().text());
				 to_transfer += '"' + $("#"+childs_to[i].id).children().children().first().text() + 
				                '":"' + $("#"+childs_to[i].id).children().children().last().attr("placeholder")+'"';
			 }
			 if(i !=  childs_to.length-2){
				 to_transfer += ',';
			 }
		 }
		 to_transfer += '}';
		 console.log(to_transfer);
		$.ajax({
			type : "post",
			url : "../context/ctxSerOrUp",
			dataType : "json",
			contentType : "application/json",
			data : to_transfer,
			success : function(data) {
				console.log("url");
				console.log(data);
				var paramStr="?userID="+u_id_wel+"&pageID="+p_id_wel;
				$.each(data, function(key, val) {
					paramStr += "&" + key + "=" + val;
				});
				console.log(paramStr);
				location.href = "../../rrui/uiSimulation/pageGenerator"+paramStr;
			},
			error : function(e) {
				alert('너 실패');
			}
		});
}
function ctxSerOrUp_User(check){
	console.log(check.id);
	var u_id_wel = $("#UserId_welcome").val();
	console.log(u_id_wel);
	var cur_ctx = [];
	var cnt_for_ctx_index=0;
	$.getJSON('../context/getContext/?ContextUserID=' + u_id_wel, function(data_u) {
		var obj_to_transfer = '{"userId":"'+ u_id_wel + '",';
		$.each(data_u, function(key, val) {
			obj_to_transfer += '"' + key + '":' ;
			cur_ctx[cnt_for_ctx_index++] = key;
			key = key.toLowerCase();
			if( $("#"+key+"_hold_id").val()){
				obj_to_transfer += '"' +  $("#"+key+"_hold_id").val() + '",';
			} else {
				obj_to_transfer += '"' +  $("#"+key+"_hold_id").attr("placeholder") + '",';
			}
		});
		obj_to_transfer = obj_to_transfer.substr(0,obj_to_transfer.length-1);
		obj_to_transfer += "}";
		console.log(obj_to_transfer);
		$.ajax({
			type : "post",
			url : "../context/ctxSerOrUp",
			dataType : "json",
			contentType : "application/json",
			data : obj_to_transfer,
			success : function(data) {
				console.log(data);
			},
			error : function(e) {
				alert('너 실패');
			}
		});
	});
}



function getContext()
{	
	var obj_to = '{';
	var p_id_wel;
	if($("#PageId_welcome").val()){
		p_id_wel = $("#PageId_welcome").val();
		obj_to += '"PageID":"' + p_id_wel + '"';
	}
	var u_id_wel; 
	if($("#UserId_welcome").val()){
		u_id_wel = $("#UserId_welcome").val();
		if(obj_to.length > 10) obj_to += ',';
		obj_to += '"ContextUserID":"' + u_id_wel + '"';
	}
	obj_to +='}';
	console.log(obj_to);
	$.ajax({
		type : "post",
		url : "../context/getContext",
		contentType : "application/json",
		data : obj_to,
		success : function(data_c) {
			console.log(data_c);
			var dynamic_contexts_p = '';
			var ck = 0;
			$.each(data_c, function(key, val) {
				dynamic_contexts_p += '<div class="dym_ctx_view_id" id="dym_ctx_view_id'+key+'">';
					dynamic_contexts_p += '<div class="input-group">';
					dynamic_contexts_p += '<span class="input-group-addon">'
							+ key + '</span>';
					dynamic_contexts_p += '<input type="text" class="form-control" id="'
							+ key.toLowerCase() +'_hold_id' + '" placeholder="'
							+ val + '" />';
					dynamic_contexts_p += '</div>';
				dynamic_contexts_p += '</div>';
				ck = 1;
			});
			if(ck){
				dynamic_contexts_p += '<div id="btn_View_id">';
					dynamic_contexts_p += '<button class="btn btn-danger" type="button" onclick="ctxSerOrUp()">Get Resource with Context!</button>';
				dynamic_contexts_p += '</div>';
			}
			$("#ctx_container").html(dynamic_contexts_p);
		},
		error : function(e) {
			alert('너 실패');
		}
	});
}