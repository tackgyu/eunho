	function getHttpParam(name) {
		var regexS = "[\\?&]" + name + "=([^&#]*)";
		var regex = new RegExp(regexS);
		var results = regex.exec(window.location.href);
		if (results == null) {
			return "";
		} else {
			return results[1];
		}
	};
	function create_form(nm,mt,ac) {
		 var fm = document.createElement("form");
		 fm.enctype='application/json';
		 fm.id = nm;
		 fm.method = mt;
		 fm.action = ac;
		 return fm;
	};
//	function loadHtml(formid, action, targetid){
//        // 파라미터의 취득
//        var fm = $(formid);
//        var param = {};
//
//        // 폼 내용을 배열로 변환
//        $(fm.serializeArray()).each(function(i, v) {
//        param[v.name] = v.value;
//        });
//        //jquery로 전송후 html형식의 리턴값을 target-url에 삽입
//        $(targetid).load(target, param); 
//    };
	function add_input(fm,nm,vu){
		 var input = document.createElement("input");
		 input.type = "hidden";
		 input.name = nm;
		 input.value =  vu;
		 fm.insertBefore(input,null);
		 return fm
	};
	function doit(){
		var p_id_wel = getHttpParam("PageID");
		$.getJSON('/rrui/rest/contextINpage?pageID=' + p_id_wel, function(data) {
			console.log(data);
			 
			 var to_trans = '{';
			 
			 for(var i = 0; i < data.contexts.length; i++){
						to_trans += '"'+data.contexts[i].ctxName+'":"' + data.contexts[i].ctxName + '"';
					if(i != data.contexts.length-1){
						to_trans += ",";
					}
				}	
				if(getHttpParam("PageID")){
					to_trans += ',"PageID":"' + getHttpParam("PageID") + '"';
				}
				if(getHttpParam("ContextUserID")){
					to_trans += ',"ContextUserID":"' + getHttpParam("ContextUserID") + '"';
				}
				to_trans += ',"op":"1"';
				
				to_trans += '}';
				
			 
			 alert("이대로 멈춰!");
			 console.log(to_trans);
			 
				$.ajax({
					type : "post",
					url : "../context/getContext",
					dataType : "json",
					contentType : "application/json",
					data : to_trans,
					success : function(data) {
						console.log("성공")
					},
					error : function(e) {
						alert('너 실패');
					}
				});
			 
			 
//			 console.log(fm);
//			 fm.submit();
			
		});
	};
	$(document).ready(function() {
		doit();
	});