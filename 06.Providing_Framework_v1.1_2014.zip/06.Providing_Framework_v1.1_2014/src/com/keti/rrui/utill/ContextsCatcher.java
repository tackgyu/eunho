package com.keti.rrui.utill;

import com.keti.rrui.vo.Context;
public class ContextsCatcher {
	
	public Context confirm(String[] contexts_, Context ctx){
		
		System.out.println("ContextsCatcher_confirm()");
		System.out.println("contexts_");
		for(int i = 1; i < contexts_.length; i++){
			if(!contexts_[i].split("=")[1].equalsIgnoreCase("*")){
				String ck[] = contexts_[i].split("=");
					if(ck[0].equalsIgnoreCase( "Age" )){ ctx.setAge(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "Gender" )){ ctx.setGender(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "Nation" )){ ctx.setNation(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "Preference" )){ ctx.setPreference(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "Tendency" )){ ctx.setTendency(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "Height" )){ ctx.setHeight(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "Weight" )){ ctx.setWeight(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "IsEarlyAdaptor" )){ ctx.setIsEarlyAdaptor(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "IsSingle" )){ ctx.setIsSingle(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "LifeStyle" )){ ctx.setLifeStyle(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "IoTStyle" )){ ctx.setIoTStyle(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "FavoriteURL" )){ ctx.setFavoriteURL(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "SleepPattern" )){ ctx.setSleepPattern(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "OnExercise" )){ ctx.setOnExercise(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "OnDiet" )){ ctx.setOnDiet(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "Location" )){ ctx.setLocation(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "Temperature" )){ ctx.setTemperature(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "AirPollution" )){ ctx.setAirPollution(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "Emotion" )){ ctx.setEmotion(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "TimeStatus" )){ ctx.setTimeStatus(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "FavoriteShopURL" )){ ctx.setFavoriteShopURL(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "Action" )){ ctx.setAction(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "Weather" )){ ctx.setWeather(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "Default" )){ ctx.setDefault(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "CD_ID" )){ ctx.setCD_ID(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "BrowsingLevel" )){ ctx.setBrowsingLevel(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "ConsumptionLevel" )){ ctx.setConsumptionLevel(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "ConsumptionChange" )){ ctx.setConsumptionChange(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "CO2" )){ ctx.setCO2(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "BloodPressure" )){ ctx.setBloodPressure(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "ExcitementIndex" )){ ctx.setExcitementIndex(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "DiscomfortIndex" )){ ctx.setDiscomfortIndex(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "TirednessIndex" )){ ctx.setTirednessIndex(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "ExerciseType" )){ ctx.setExerciseType(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "Group" )){ ctx.setGroup(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "Icon" )){ ctx.setIcon(contexts_[i].split("=")[1]); }
					else if(ck[0].equalsIgnoreCase( "Device" )){ ctx.setDevice(contexts_[i].split("=")[1]); }
			}
		}
		return ctx;
	}
	
	public String confirm_reverse(Context ctx, String ctx_prop){
		System.out.println("ContextsCatcher_confirm_reverse()");
		if(ctx_prop.equalsIgnoreCase( "Age" )){ return ctx.getAge(); }
		else if(ctx_prop.equalsIgnoreCase( "Gender" )){ return ctx.getGender();}
		else if(ctx_prop.equalsIgnoreCase( "Nation" )){ return ctx.getAge(); }
		else if(ctx_prop.equalsIgnoreCase( "Preference" )){ return ctx.getPreference();}
		else if(ctx_prop.equalsIgnoreCase( "Tendency" )){ return ctx.getTendency(); }
		else if(ctx_prop.equalsIgnoreCase( "Height" )){ return ctx.getHeight(); }
		else if(ctx_prop.equalsIgnoreCase( "Weight" )){ return ctx.getWeight(); }
		else if(ctx_prop.equalsIgnoreCase( "IsEarlyAdaptor" )){ return ctx.getIsEarlyAdaptor(); }
		else if(ctx_prop.equalsIgnoreCase( "IsSingle" )){ return ctx.getIsSingle(); }
		else if(ctx_prop.equalsIgnoreCase( "LifeStyle" )){ return ctx.getLifeStyle(); }
		else if(ctx_prop.equalsIgnoreCase( "IoTStyle" )){ return ctx.getIoTStyle(); }
		else if(ctx_prop.equalsIgnoreCase( "FavoriteURL" )){ return ctx.getFavoriteURL(); }
		else if(ctx_prop.equalsIgnoreCase( "SleepPattern" )){ return ctx.getSleepPattern(); }
		else if(ctx_prop.equalsIgnoreCase( "OnExercise" )){ return ctx.getOnExercise(); }
		else if(ctx_prop.equalsIgnoreCase( "OnDiet" )){ return ctx.getOnDiet(); }
		else if(ctx_prop.equalsIgnoreCase( "Location" )){ return ctx.getLocation(); }
		else if(ctx_prop.equalsIgnoreCase( "Temperature" )){ return ctx.getTemperature(); }
		else if(ctx_prop.equalsIgnoreCase( "AirPollution" )){ return ctx.getAirPollution(); }
		else if(ctx_prop.equalsIgnoreCase( "Emotion" )){ return ctx.getEmotion(); }
		else if(ctx_prop.equalsIgnoreCase( "TimeStatus" )){ return ctx.getTimeStatus(); }
		else if(ctx_prop.equalsIgnoreCase( "FavoriteShopURL" )){ return ctx.getFavoriteShopURL(); }
		else if(ctx_prop.equalsIgnoreCase( "Action" )){ return ctx.getAction(); }
		else if(ctx_prop.equalsIgnoreCase( "Weather" )){ return ctx.getWeather(); }
		else if(ctx_prop.equalsIgnoreCase( "Default" )){ return ctx.getDefault(); }
		else if(ctx_prop.equalsIgnoreCase( "CD_ID" )){ return ctx.getCD_ID();}
		else if(ctx_prop.equalsIgnoreCase( "BrowsingLevel" )){ return ctx.getBrowsingLevel(); }
		else if(ctx_prop.equalsIgnoreCase( "ConsumptionLevel" )){ return ctx.getConsumptionLevel(); }
		else if(ctx_prop.equalsIgnoreCase( "ConsumptionChange" )){ return ctx.getConsumptionChange(); }
		else if(ctx_prop.equalsIgnoreCase( "CO2" )){ return ctx.getCO2(); }
		else if(ctx_prop.equalsIgnoreCase( "BloodPressure" )){ return ctx.getBloodPressure(); }
		else if(ctx_prop.equalsIgnoreCase( "ExcitementIndex" )){ return ctx.getExcitementIndex(); }
		else if(ctx_prop.equalsIgnoreCase( "DiscomfortIndex" )){ return ctx.getDiscomfortIndex();  }
		else if(ctx_prop.equalsIgnoreCase( "TirednessIndex" )){ return ctx.getTirednessIndex();  }
		else if(ctx_prop.equalsIgnoreCase( "ExerciseType" )){ return ctx.getExerciseType();  }
		else if(ctx_prop.equalsIgnoreCase( "Group" )){ return ctx.getGroup();  }
		else if(ctx_prop.equalsIgnoreCase( "Icon" )){ return ctx.getIcon();  }
		else if(ctx_prop.equalsIgnoreCase( "Device" )){ return ctx.getDevice();  }
		return "";
	}
	
}
