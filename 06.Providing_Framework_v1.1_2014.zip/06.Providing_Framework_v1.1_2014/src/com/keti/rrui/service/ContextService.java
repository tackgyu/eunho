package com.keti.rrui.service;

import java.util.List;

import com.keti.rrui.vo.Context;

public interface ContextService {
	
	public Context getContext(String ContextUserID);
	public int UpdateContext(Context ctx);
	public String getCtxPincode(String ContextUserID);
	public List<Context> getContextAll();
	
}
