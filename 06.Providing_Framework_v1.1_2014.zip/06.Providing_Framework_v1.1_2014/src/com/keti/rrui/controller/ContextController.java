package com.keti.rrui.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletResponse;



//import org.json.simple.JSONObject;
import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import com.google.gson.JsonObject;
import com.keti.rrui.service.ContextService;
import com.keti.rrui.utill.ContextsCatcher;
import com.keti.rrui.vo.Context;

@Controller
@RequestMapping(value = "/context")
public class ContextController {

	@Autowired
	ContextService contextService;

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "ctxSerOrUp", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody JSONObject ctxSerOrUp(
			@RequestBody Map<String, String> params) {

		System.out.println(params);
		String contexts = "";
		Set<String> keys = params.keySet();

		for (String key : keys) {
			contexts += key + "=" + params.get(key) + "#";
		}
		contexts = contexts.substring(0, contexts.length() - 1);

		System.out.println(contexts);

		// the set of ContextName=value
		// the first element is the UserId
		String[] contexts_ = contexts.split("#");

		// Get the before Context by using the UserId
		Context ctx = contextService.getContext(contexts_[0].split("=")[1]);

		System.out.println("Before : ");
		System.out.println(ctx);

		// upDate Context elements
		ContextsCatcher conCat = new ContextsCatcher();
		ctx = conCat.confirm(contexts_, ctx);

		System.out.println("After : ");
		System.out.println(ctx);

		// Update Database
		contextService.UpdateContext(ctx);

		JSONObject json = new JSONObject();
		params.remove("ContextUserID");
		keys = params.keySet();
		for (String key : keys) {
			json.put(key, params.get(key));
		}
		System.out.println("��쇱�ㅽ�명��~");
		System.out.println(json);
		return json;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "getContext", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody JSONObject getContext(HttpServletResponse response,
			@RequestBody Map<String, String> params) {

		System.out.println("#######################################################");
		System.out.println(params);

		Context ctx = null;
		JSONObject json = new JSONObject();
		
		if (params.get("PageID") == null && params.get("ContextUserID") != null) {
			// pageID(NULL), ContextUserID(O) --> ContextAll
			ctx = contextService.getContext(params.get("ContextUserID"));
			json =  JSONObject.fromObject(ctx);
		} else if (params.get("PageID") != null && params.get("ContextUserID") == null) {
			Map<String, String> params_inner = new HashMap();
			params_inner.put("pageID", params.get("PageID"));
			List<NameValuePair> paramList = convertParam(params_inner);
			HttpClient client = new DefaultHttpClient();
			HttpGet get = new HttpGet(
					"localhost:8080/rrui/rest/contextINpage?"
							+ URLEncodedUtils
									.format(paramList, "UTF-8"));
			System.out.println("GET : " + get.getURI());

			ResponseHandler<String> rh = new BasicResponseHandler();
			try {
				String answer = client.execute(get, rh);
				System.out.println(answer);
				answer = answer.replace(":[{", "");
				String answer_[] = answer.split(",");
				String t_page_id = params.get("PageID");
				String t_ContextUserID = params.get("ContextUserID");
				params.clear();
				for (int i = 0; i < answer_.length; i++) {
					if (answer_[i].split(":")[0].contains("ctxName")) {
						String val_ = answer_[i].split(":")[1];
						System.out.println("ctx : " + val_);
						String val_p = "";
						for (int k = 0; k < val_.length(); k++) {
							if (val_.charAt(k) != 34) {
								val_p += val_.charAt(k);
							}
						}
						params.put(val_p, val_p);
					}
				}
				params.put("pageID", t_page_id);
			} catch (ClientProtocolException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			params.remove("pageID");
			Set<String> keys = params.keySet();
			for (String key : keys) {
				json.put(key, key);
			}
		} else if (params.get("PageID") != null	&& params.get("ContextUserID") != null) {
			Map<String, String> params_inner = new HashMap();
			params_inner.put("pageID", params.get("PageID"));
			List<NameValuePair> paramList = convertParam(params_inner);
			HttpClient client = new DefaultHttpClient();

			HttpGet get = new HttpGet(
					"localhost:8080/rrui/rest/contextINpage?"
							+ URLEncodedUtils.format(paramList, "UTF-8"));
			System.out.println("GET : " + get.getURI());

			ResponseHandler<String> rh = new BasicResponseHandler();
			try {
				String answer = client.execute(get, rh);
				answer = answer.replace(":[{", "");
				String answer_[] = answer.split(",");
				String t_page_id = params.get("PageID");
				String t_ContextUserID = params.get("ContextUserID");
				params.clear();
				for (int i = 0; i < answer_.length; i++) {
					if (answer_[i].split(":")[0].contains("ctxName")) {
						String val_ = answer_[i].split(":")[1];
						System.out.println("ctx : " + val_);
						String val_p = "";
						for (int k = 0; k < val_.length(); k++) {
							if (val_.charAt(k) != 34) {
								val_p += val_.charAt(k);
							}
						}
						params.put(val_p, val_p);
					}
				}
				params.put("pageID", t_page_id);
				params.put("ContextUserID", t_ContextUserID);
			} catch (ClientProtocolException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			ctx = contextService.getContext(params.get("ContextUserID"));
			params.remove("pageID");
			params.remove("ContextUserID");
			System.out.println(ctx);
			Set<String> keys = params.keySet();
			ContextsCatcher conCat = new ContextsCatcher();
			System.out.println(params);
			System.out.println(keys);
			for (String key : keys) {
				System.out.println("key : " + key);
				json.put(key, conCat.confirm_reverse(ctx, key));
			}
		}
		System.out.println("��쇱�ㅽ�명��~");
		System.out.println(json);
		return json;
	}
	
	@RequestMapping(value = "/getContextAll", method = RequestMethod.GET)
	public @ResponseBody List<Context> getContextAll() {
		System.out.println("getContextAll()");
		return contextService.getContextAll();
	}
	
	// 援ъ“�����쇰�� 留�吏� ������
	// Just test
	@RequestMapping(value = "/getPageAll", method = RequestMethod.GET)
	public @ResponseBody List<Map<String, String>> getPageAll() {
		System.out.println("getPageAll()");
		List<Map<String, String>> result = new LinkedList<Map<String, String>>();
		HttpClient client = new DefaultHttpClient();
//		HttpGet get = new HttpGet("http://localhost:8080/rrui/rest/getPageAll");
		HttpGet get = new HttpGet("localhost:8080/rrui/rest/getPageAll");
		System.out.println("GET : " + get.getURI());
		ResponseHandler<String> rh = new BasicResponseHandler();
		try {
			String answer = client.execute(get, rh);
			System.out.println(answer);
			String findDevide[] = answer.split("}");
			for(int i = 0; i < findDevide.length-1; i++){
				String findID_ = findDevide[i].split("pageID")[1].split(",")[0];
				findID_ = findID_.substring(findID_.indexOf(":")+1);
				String findTitle_ = findDevide[i].split("pageTitle")[1].split(",")[0];
				findTitle_ = findTitle_.substring(findTitle_.indexOf(":")+1);
				String val_id_ = findID_;
				String val_id_p = "";
				for (int k = 0; k < val_id_.length(); k++) {
					if (val_id_.charAt(k) != 34) {
						val_id_p += val_id_.charAt(k);
					}
				}
				String val_title_ = findTitle_;
				String val_title_p = "";
				for (int k = 0; k < val_title_.length(); k++) {
					if (val_title_.charAt(k) != 34) {
						val_title_p += val_title_.charAt(k);
					}
				}
				Map<String, String> map_ = new HashMap<String, String>();
				map_.put("id",val_id_p);
				map_.put("title",val_title_p);
				System.out.println(map_);
				result.add(map_);
			}
			System.out.println(answer);
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}

	@RequestMapping(value = "/getCtxPincode", method = RequestMethod.GET)
	public @ResponseBody String getCtxPincode(
			@RequestParam("ContextUserID") String ContextUserID) {
		System.out.println("getCtxPincode()");
		return contextService.getCtxPincode(ContextUserID);
	}

	private List<NameValuePair> convertParam(Map params) {
		List<NameValuePair> paramList = new ArrayList<NameValuePair>();
		Iterator<String> keys = params.keySet().iterator();
		while (keys.hasNext()) {
			String key = keys.next();
			paramList.add(new BasicNameValuePair(key, params.get(key)
					.toString()));
		}

		return paramList;
	}

}
