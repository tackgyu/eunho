package com.keti.rrui.dao;


import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.keti.rrui.vo.Context;


@Repository
public class ContextDao {
	@Autowired
	private SqlSession sqlSession;

	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}

	public int UpdateContext(Context ctx) {
		return sqlSession.update("UpdateContext", ctx);
	}

	public Context getContext(String ContextUserID) {
		return  sqlSession.selectOne("getContext", ContextUserID);
	}
	
	public String getCtxPincode(String ContextUserID) {
		return  sqlSession.selectOne("getCtxPincode", ContextUserID);
	}
	
	public List<Context> getContextAll() {
		return  sqlSession.selectList("getContextAll");
	}
}
