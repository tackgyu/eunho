package com.keti.rrui.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.keti.rrui.dao.ContextDao;
import com.keti.rrui.service.ContextService;
import com.keti.rrui.vo.Context;

@Service
public class ContextServiceImpl implements ContextService{
	
	@Autowired
	ContextDao ctxDao;

	@Override
	public Context getContext(String ContextUserID) {
		return ctxDao.getContext(ContextUserID);
	}

	@Override
	public int UpdateContext(Context ctx) {
		return ctxDao.UpdateContext(ctx);
	}
	

	@Override
	public String getCtxPincode(String ContextUserID) {
		return ctxDao.getCtxPincode(ContextUserID);
	}

	@Override
	public List<Context> getContextAll() {
		return ctxDao.getContextAll();
	}
	
	
}
