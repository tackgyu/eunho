package com.keti.rrui.model;

public class testModel {
	String id;
	String ctx1;
	String ctx2;
	String ctx3;
	String ctx4;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCtx1() {
		return ctx1;
	}
	public void setCtx1(String ctx1) {
		this.ctx1 = ctx1;
	}
	public String getCtx2() {
		return ctx2;
	}
	public void setCtx2(String ctx2) {
		this.ctx2 = ctx2;
	}
	public String getCtx3() {
		return ctx3;
	}
	public void setCtx3(String ctx3) {
		this.ctx3 = ctx3;
	}
	public String getCtx4() {
		return ctx4;
	}
	public void setCtx4(String ctx4) {
		this.ctx4 = ctx4;
	}
	
	
	
}
