package com.keti.rrui.vo;

public class Context {
	private String UserID; 
	private String Pincode; 
	private String Age; 
	private String Gender; 
	private String Nation; 
	private String Preference; 
	private String Tendency; 
	private String Height; 
	private String Weight; 
	private String IsEarlyAdaptor; 
	private String IsSingle; 
	private String LifeStyle; 
	private String Weather; 
	private String Location; 
	private String Temperature; 
	private String AirPollution; 
	private String Emotion; 
	private String TimeStatus; 
	private String Action; 
	private String IoTStyle; 
	private String FavoriteURL; 
	private String SleepPattern; 
	private String OnExercise; 
	private String OnDiet; 
	private String FavoriteShopURL; 
	//
	private String Default;
	private String CD_ID; 
	private String BrowsingLevel; 
	private String ConsumptionLevel; 
	private String ConsumptionChange; 
	private String CO2; 
	private String BloodPressure; 
	private String ExcitementIndex; 
	private String DiscomfortIndex; 
	private String TirednessIndex; 
	private String ExerciseType; 
	private String Group; 
	private String Icon; 
	private String Device; 
	
	
	public String getDevice() {
		return Device;
	}

	public void setDevice(String device) {
		Device = device;
	}

	public String getCD_ID() {
		return CD_ID;
	}

	public void setCD_ID(String cD_ID) {
		CD_ID = cD_ID;
	}

	public String getBrowsingLevel() {
		return BrowsingLevel;
	}

	public void setBrowsingLevel(String browsingLevel) {
		BrowsingLevel = browsingLevel;
	}

	public String getConsumptionLevel() {
		return ConsumptionLevel;
	}

	public void setConsumptionLevel(String consumptionLevel) {
		ConsumptionLevel = consumptionLevel;
	}

	public String getConsumptionChange() {
		return ConsumptionChange;
	}

	public void setConsumptionChange(String consumptionChange) {
		ConsumptionChange = consumptionChange;
	}

	public String getCO2() {
		return CO2;
	}

	public void setCO2(String cO2) {
		CO2 = cO2;
	}

	public String getBloodPressure() {
		return BloodPressure;
	}

	public void setBloodPressure(String bloodPressure) {
		BloodPressure = bloodPressure;
	}

	public String getExcitementIndex() {
		return ExcitementIndex;
	}

	public void setExcitementIndex(String excitementIndex) {
		ExcitementIndex = excitementIndex;
	}

	public String getDiscomfortIndex() {
		return DiscomfortIndex;
	}

	public void setDiscomfortIndex(String discomfortIndex) {
		DiscomfortIndex = discomfortIndex;
	}

	public String getTirednessIndex() {
		return TirednessIndex;
	}

	public void setTirednessIndex(String tirednessIndex) {
		TirednessIndex = tirednessIndex;
	}

	public String getExerciseType() {
		return ExerciseType;
	}

	public void setExerciseType(String exerciseType) {
		ExerciseType = exerciseType;
	}

	public String getGroup() {
		return Group;
	}

	public void setGroup(String group) {
		Group = group;
	}

	public String getIcon() {
		return Icon;
	}

	public void setIcon(String icon) {
		Icon = icon;
	}

	public String getDefault() {
		return Default;
	}

	public void setDefault(String default1) {
		Default = default1;
	}

	public String getUserID() {
		return UserID;
	}

	public Context setUserID(String UserID) {
		this.UserID = UserID;
		return this;
	}

	public String getPincode() {
		return Pincode;
	}

	public Context setPincode(String pincode) {
		Pincode = pincode;
		return this;
	}

	public String getAge() {
		return Age;
	}

	public Context setAge(String age) {
		Age = age;
		return this;
	}

	public String getGender() {
		return Gender;
	}

	public Context setGender(String gender) {
		Gender = gender;
		return this;
	}

	public String getNation() {
		return Nation;
	}

	public Context setNation(String nation) {
		Nation = nation;
		return this;
	}

	public String getPreference() {
		return Preference;
	}

	public Context setPreference(String preference) {
		Preference = preference;
		return this;
	}

	public String getTendency() {
		return Tendency;
	}

	public Context setTendency(String tendency) {
		Tendency = tendency;
		return this;
	}

	public String getHeight() {
		return Height;
	}

	public Context setHeight(String height) {
		Height = height;
		return this;
	}

	public String getWeight() {
		return Weight;
	}

	public Context setWeight(String weight) {
		Weight = weight;
		return this;
	}

	public String getIsEarlyAdaptor() {
		return IsEarlyAdaptor;
	}

	public Context setIsEarlyAdaptor(String isEarlyAdaptor) {
		IsEarlyAdaptor = isEarlyAdaptor;
		return this;
	}

	public String getIsSingle() {
		return IsSingle;
	}

	public Context setIsSingle(String isSingle) {
		IsSingle = isSingle;
		return this;
	}

	public String getLifeStyle() {
		return LifeStyle;
	}

	public Context setLifeStyle(String lifeStyle) {
		LifeStyle = lifeStyle;
		return this;
	}

	public String getIoTStyle() {
		return IoTStyle;
	}

	public Context setIoTStyle(String ioTStyle) {
		IoTStyle = ioTStyle;
		return this;
	}

	public String getFavoriteURL() {
		return FavoriteURL;
	}

	public Context setFavoriteURL(String FavoriteURL) {
		this.FavoriteURL = FavoriteURL;
		return this;
	}

	public String getFavoriteShopURL() {
		return FavoriteShopURL;
	}

	public void setFavoriteShopURL(String favoriteShopURL) {
		FavoriteShopURL = favoriteShopURL;
	}

	public String getSleepPattern() {
		return SleepPattern;
	}

	public Context setSleepPattern(String sleepPattern) {
		SleepPattern = sleepPattern;
		return this;
	}

	public String getOnExercise() {
		return OnExercise;
	}

	public Context setOnExercise(String onExercise) {
		OnExercise = onExercise;
		return this;
	}

	public String getOnDiet() {
		return OnDiet;
	}

	public Context setOnDiet(String onDiet) {
		OnDiet = onDiet;
		return this;
	}

	public String getLocation() {
		return Location;
	}

	public Context setLocation(String location) {
		Location = location;
		return this;
	}

	public String getTemperature() {
		return Temperature;
	}

	public Context setTemperature(String temperature) {
		Temperature = temperature;
		return this;
	}

	public String getAirPollution() {
		return AirPollution;
	}

	public Context setAirPollution(String airPollution) {
		AirPollution = airPollution;
		return this;
	}

	public String getEmotion() {
		return Emotion;
	}

	public Context setEmotion(String emotion) {
		Emotion = emotion;
		return this;
	}

	public String getTimeStatus() {
		return TimeStatus;
	}

	public Context setTimeStatus(String timeStatus) {
		TimeStatus = timeStatus;
		return this;
	}

	// public String getPhysicalCondition() {
	// return PhysicalCondition;
	// }
	// public Context setPhysicalCondition(String physicalCondition) {
	// PhysicalCondition = physicalCondition;
	// return this;
	// }
	public String getAction() {
		return Action;
	}

	public Context setAction(String action) {
		Action = action;
		return this;
	}

	public String getWeather() {
		return Weather;
	}

	public Context setWeather(String weather) {
		Weather = weather;
		return this;
	}

	@Override
	public String toString() {
		return "Context [UserID=" + UserID + ", Pincode=" + Pincode + ", Age="
				+ Age + ", Gender=" + Gender + ", Nation=" + Nation
				+ ", Preference=" + Preference + ", Tendency=" + Tendency
				+ ", Height=" + Height + ", Weight=" + Weight
				+ ", IsEarlyAdaptor=" + IsEarlyAdaptor + ", IsSingle="
				+ IsSingle + ", LifeStyle=" + LifeStyle + ", Weather="
				+ Weather + ", Location=" + Location + ", Temperature="
				+ Temperature + ", AirPollution=" + AirPollution + ", Emotion="
				+ Emotion + ", TimeStatus=" + TimeStatus + ", Action=" + Action
				+ ", IoTStyle=" + IoTStyle + ", FavoriteURL=" + FavoriteURL
				+ ", SleepPattern=" + SleepPattern + ", OnExercise="
				+ OnExercise + ", OnDiet=" + OnDiet + ", FavoriteShopURL="
				+ FavoriteShopURL + ", Default=" + Default + ", CD_ID=" + CD_ID
				+ ", BrowsingLevel=" + BrowsingLevel + ", ConsumptionLevel="
				+ ConsumptionLevel + ", ConsumptionChange=" + ConsumptionChange
				+ ", CO2=" + CO2 + ", BloodPressure=" + BloodPressure
				+ ", ExcitementIndex=" + ExcitementIndex + ", DiscomfortIndex="
				+ DiscomfortIndex + ", TirednessIndex=" + TirednessIndex
				+ ", ExerciseType=" + ExerciseType + ", Group=" + Group
				+ ", Icon=" + Icon + ", Device=" + Device + "]";
	}


}